// Trator + Drone - Versão Funcional
// SETAS = dirigir | ESPAÇO = ação | C = colher | E = modo | D = drone R$50

let trator;
let campos = [];
let pontos = 0, dinheiro = 300;
let modo = 0; // 0=arar, 1=plantar, 2=colher
let diesel = 100, agua = 100;
let drone = {ativo: false, x: 0, y: 0, tempo: 0};
let pragas = [];

function setup() {
  createCanvas(800, 600);
  trator = {x: 400, y: 300, dir: 0};

  for(let i = 0; i < 10; i++) {
    campos[i] = [];
    for(let j = 0; j < 8; j++) {
      campos[i][j] = {tipo: 0, praga: false}; // 0=terra,1=arado,2=plantado,3=maduro
    }
  }
}

function draw() {
  background(135, 206, 250);

  // Spawn praga aleatória
  if(random() < 0.002) {
    let i = floor(random(10));
    let j = floor(random(8));
    if(campos[i][j].tipo >= 2 &&!campos[i][j].praga) {
      campos[i][j].praga = true;
      pragas.push({x: i*80+40, y: j*60+30});
    }
  }

  // Desenha campos
  for(let i = 0; i < 10; i++) {
    for(let j = 0; j < 8; j++) {
      let x = i * 80, y = j * 60;
      let c = campos[i][j];

      if(c.tipo == 0) fill(139, 90, 43);
      if(c.tipo == 1) fill(101, 67, 33);
      if(c.tipo == 2) fill(50, 205, 50);
      if(c.tipo == 3) fill(255, 215, 0);
      if(c.praga) fill(200, 0, 0); // vermelho se tem praga

      rect(x, y, 80, 60);
      stroke(0);
      noFill();
      rect(x, y, 80, 60);
      noStroke();

      if(c.praga) {
        fill(255);
        textSize(20);
        text("!", x+40, y+35);
      }
    }
  }

  // Crescimento
  if(frameCount % 180 == 0) {
    for(let i = 0; i < 10; i++) {
      for(let j = 0; j < 8; j++) {
        if(campos[i][j].tipo == 2 &&!campos[i][j].praga) {
          campos[i][j].tipo = 3;
        }
      }
    }
  }

  // Drone
  if(drone.ativo) {
    drone.tempo++;
    fill(100);
    ellipse(drone.x, drone.y, 25, 10);
    fill(150);
    rect(drone.x-20, drone.y, 8, 3);
    rect(drone.x+20, drone.y, 8, 3);

    // Scan visual
    noFill();
    stroke(0, 255, 255, 100);
    strokeWeight(3);
    ellipse(drone.x, drone.y, drone.tempo*4);
    noStroke();

    if(drone.tempo > 60) {
      drone.ativo = false;
      // Revela pragas com círculo
      for(let p of pragas) {
        fill(255, 0, 0, 150);
        ellipse(p.x, p.y, 50, 50);
      }
    }
  }

  // Trator
  push();
  translate(trator.x, trator.y);
  rotate(trator.dir * PI/2);
  fill(255, 0, 0);
  rect(-15, -10, 30, 20);
  fill(0, 100, 255);
  rect(5, -8, 12, 16);
  fill(0);
  ellipse(-12, -10, 15, 15);
  ellipse(-12, 10, 15, 15);
  ellipse(12, -8, 10, 10);
  ellipse(12, 8, 10, 10);
  pop();

  // HUD
  fill(0);
  textSize(14);
  textAlign(LEFT);
  text("Pontos: " + pontos + " | R$: " + dinheiro, 10, 20);
  text("Diesel: " + floor(diesel) + "% | Água: " + floor(agua) + "%", 10, 40);

  let modos = ["ARAR", "PLANTAR", "COLHER"];
  text("Modo: " + modos[modo] + " | E=trocar", 10, 580);
  text("ESPAÇO=ação | C=colher | D=drone R$50 | SETAS=dirigir", 10, 560);

  // Controles
  if(keyIsDown(LEFT_ARROW)) { trator.x -= 3; trator.dir = 2; diesel -= 0.05; }
  if(keyIsDown(RIGHT_ARROW)) { trator.x += 3; trator.dir = 0; diesel -= 0.05; }
  if(keyIsDown(UP_ARROW)) { trator.y -= 3; trator.dir = 3; diesel -= 0.05; }
  if(keyIsDown(DOWN_ARROW)) { trator.y += 3; trator.dir = 1; diesel -= 0.05; }

  trator.x = constrain(trator.x, 20, 780);
  trator.y = constrain(trator.y, 20, 480);

  diesel = max(0, diesel);
  agua = max(0, agua);
}

function keyPressed() {
  if(key == 'e' || key == 'E') modo = (modo + 1) % 3;

  if(key == 'd' || key == 'D') {
    if(dinheiro >= 50 &&!drone.ativo) {
      dinheiro -= 50;
      drone.ativo = true;
      drone.x = trator.x;
      drone.y = trator.y;
      drone.tempo = 0;
    }
  }

  if(key == ' ') {
    let i = floor(trator.x / 80);
    let j = floor(trator.y / 60);
    if(i >= 0 && i < 10 && j >= 0 && j < 8) {
      let c = campos[i][j];
      if(modo == 0 && c.tipo == 0 && diesel > 0) {
        c.tipo = 1; diesel -= 2;
      }
      if(modo == 1 && c.tipo == 1 && agua > 0 && dinheiro >= 10) {
        c.tipo = 2; agua -= 5; dinheiro -= 10; pontos += 10;
      }
      if(modo == 2 && c.tipo == 3) {
        c.tipo = 0; c.praga = false; pontos += 100; dinheiro += 50;
        // Remove praga visual
        for(let k = pragas.length-1; k >= 0; k--) {
          if(pragas[k].x == i*80+40 && pragas[k].y == j*60+30) {
            pragas.splice(k, 1);
          }
        }
      }
    }
  }

  if(key == 'c' || key == 'C') {
    let i = floor(trator.x / 80);
    let j = floor(trator.y / 60);
    if(i >= 0 && i < 10 && j >= 0 && j < 8) {
      if(campos[i][j].tipo == 3) {
        campos[i][j].tipo = 0;
        campos[i][j].praga = false;
        pontos += 100;
        dinheiro += 50;
      }
    }
  }
}